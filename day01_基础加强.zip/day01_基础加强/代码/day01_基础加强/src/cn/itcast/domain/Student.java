package cn.itcast.domain;

public class Student {


    public void sleep(){
        System.out.println("sleep...");
    }
}
