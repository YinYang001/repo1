package cn.itcast.annotation;

public class Teacher extends  Worker {
}
