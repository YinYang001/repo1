package cn.itcast.annotation;

public class Demo2 {
    public void show(){
        System.out.println("demo2...show...");
    }
}
