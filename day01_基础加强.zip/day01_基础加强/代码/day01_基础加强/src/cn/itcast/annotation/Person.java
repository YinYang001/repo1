package cn.itcast.annotation;

public enum Person {

    P1,P2;
}
