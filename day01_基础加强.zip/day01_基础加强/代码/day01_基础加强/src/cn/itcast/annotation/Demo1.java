package cn.itcast.annotation;

public class Demo1 {
    public void show(){
        System.out.println("demo1...show...");
    }
}
