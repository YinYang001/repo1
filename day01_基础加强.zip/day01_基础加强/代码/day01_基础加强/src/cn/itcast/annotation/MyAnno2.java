package cn.itcast.annotation;

public @interface MyAnno2 {

}
